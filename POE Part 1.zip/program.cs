using System;
using System.Globalization;

namespace RecipeMaker
{
    class Program
    {
        static void Main(string[] args)
        {
            Scanner input = new Scanner(Console.In); // Creating a scanner object to read user inout

            Console.WriteLine("Welcome to Recipe Maker");

            Console.WriteLine("Enter recipe name:");
            string recipeName = input.nextLine(); //get the recipe name

            Console.WriteLine("Enter the number of ingredients you are going to use for this recipe:");
            int recipeNumber = input.nextInt();//get the number of recipes from the user. 

            //Storing the ingredients
            string[] ingredients = new string[recipeNumber];
            double[] quantities = new double[recipeNumber];
            string[] units = new string[recipeNumber];

            for (int i = 0; i < recipeNumber; i++)
            {
                Console.Write($"Ingredient {i + 1} (name, quantity, unit): ");
                string ingredientLine = input.nextLine();
                string[] parts = ingredientLine.Split(','); // Split each ingredient attribute(name, quantity and unit) by comma

                if (parts.Length != 3)
                {
                    Console.WriteLine("Invalid format! Please enter the name of the ingredient, quantity and unit of measurement");
                    i--; // Prompt user to re-enter the values using a correct format.
                    continue;
                }

                ingredients[i] = parts[0].Trim();
                quantities[i] = Double.Parse(parts[1].Trim(), CultureInfo.InvariantCulture); // Handle parsing with invariant culture
                units[i] = parts[2].Trim();
            }

            // Get number of steps from the user
            Console.Write("Enter the number of steps: ");
            int numSteps = input.nextInt();

            // Store steps
            string[] steps = new string[numSteps];

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Step {i + 1}: ");
                steps[i] = input.nextLine();
            }

            // Get scaling factor
            double scaleFactor;
            while (true)
            {
                Console.WriteLine("\nEnter the scale you would like to factor your recipe by (double, half, or triple): ");
                string scaleInput = input.nextLine().ToLower();

                if (scaleInput.Equals("double"))
                {
                    scaleFactor = 2.0;
                    break;
                }
                else if (scaleInput.Equals("half"))
                {
                    scaleFactor = 0.5;
                    break;
                }
                else if (scaleInput.Equals("triple"))
                {
                    scaleFactor = 3.0;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid scaling factor. Please enter double, half, or triple."); //prompt the user to enter the correct scaling factor
                }
            }

            // Apply scaling factor
            for (int i = 0; i < recipeNumber; i++)
            {
                quantities[i] *= scaleFactor;
            }

            Console.WriteLine("\nRecipe created successfully!");

            // Summarize recipe
            Console.WriteLine("\nScaled Recipe Summary:");
            Console.WriteLine($"  Name: {recipeName}");
            Console.WriteLine("  Ingredients:");

            for (int i = 0; i < recipeNumber; i++)
            {
                Console.WriteLine($"    - {quantities[i]:F2} {units[i]} {ingredients[i]}"); // Format quantity with two decimal places
            }

            Console.WriteLine("  Steps:");
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"    {i + 1}. {steps[i]}");
            }
        }
    }

    public class Scanner // Simulate Scanner class functionality for clarity
    {
        public string nextLine()
        {
            return Console.ReadLine();
        }

        public int nextInt()
        {
            return int.Parse(Console.ReadLine());
        }
    }
}